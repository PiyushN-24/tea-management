from sqlalchemy import Column
from sqlalchemy import Integer
from sqlalchemy import String

from app.db.base import Base


class User(Base):

    __tablename__ = "users"

    id = Column(Integer,primary_key=True)

    name = Column(String)

    employee_code=Column(String,unique=True)

    email = Column(String, unique=True)

    password = Column(String)

    role = Column(String, default="user")

    location = Column(String(100))

